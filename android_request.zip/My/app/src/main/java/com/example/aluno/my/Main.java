package com.example.aluno.my;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Main extends AppCompatActivity {
    EditText edt;
    String url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt = (EditText)findViewById(R.id.texto);


    }

    public void click(View view) {
        String url = edt.getText().toString();
        Toast.makeText(this, url, Toast.LENGTH_SHORT).show();

        url = "https://api.github.com/users/kanekajaum";
        final JsonObjectRequest requisicao = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                if (response.has("login")){

                    try {
                        double login = response.getDouble("login");
                        edt.setText(String.format(" Login: ", login));

                    }catch (JSONException e){

                        edt.setText("Erro de requição");
                        e.printStackTrace();
                    }


                }else{
                    edt.setText("Erro de requição");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
    );
    RequestQueue fila = Volley.newRequestQueue(this);
    fila.add(requisicao);

    }

}
